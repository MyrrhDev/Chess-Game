package Domini;

public class EstrategiaCompleja extends Estrategia {

    void estrategiaOfensiva() {

    }

    void estrategiaDefensiva() {

    }
}
