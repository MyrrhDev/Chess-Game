package Domini;

public class Ranking {
    int numJugadores;
    int puntMax;
    int puntMin;

    public int getNumJugadores() {
        return numJugadores;
    }

    public void setNumJugadores(int numJugadores) {
        this.numJugadores = numJugadores;
    }

    public int getPuntMax() {
        return puntMax;
    }

    public void setPuntMax(int puntMax) {
        this.puntMax = puntMax;
    }

    public int getPuntMin() {
        return puntMin;
    }

    public void setPuntMin(int puntMin) {
        this.puntMin = puntMin;
    }
}
